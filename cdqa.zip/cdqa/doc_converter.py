#convert docx to pdf
import os
from time import strftime
from win32com import client

def n_files(directory):
    total = 0
    for file in os.listdir(directory):
        if (file.endswith('.doc') or file.endswith('.docx') ):
            total += 1
    return total

def docxtopdf(directory):
    
    if n_files(directory) == 0:
        print('There are no files to convert')
        exit()
		
    
	
    # Opens each file with Microsoft Word and saves as a PDF
    try:
        word = client.DispatchEx('Word.Application')
        for file in os.listdir(directory):
            if (file.endswith('.doc') or file.endswith('.docx') or file.endswith('.tmd')):
                ending = ""
                if file.endswith('.doc'):
                    ending = '.doc'
                if file.endswith('.docx'):
                    ending = '.docx'
                try:
                    new_name = file.replace(ending,r".pdf")
                    in_file = os.path.abspath(directory + '\\' + file)
                    new_file = os.path.abspath(directory  + '\\' + new_name)
                    doc = word.Documents.Open(in_file)
                    print(new_name)
                    doc.SaveAs(new_file,FileFormat = 17)
                    doc.Close()
                except:
                    print("Could not open file -  ", new_name)
    except :
        print("Could not open ", )
    finally:
        word.Quit()


#%% Convert ppt to pdf
import win32com
import os

def ppttopdf(path):
 ppttoPDF = 32	
 for root, dirs, files in os.walk(path):
    for f in files:

        if f.endswith(".pptx"):
            try:
                print(f)
                in_file=os.path.join(root,f)
                powerpoint = win32com.client.Dispatch("Powerpoint.Application")
                deck = powerpoint.Presentations.Open(in_file)
                in_file = os.path.abspath(path + '\\' + f)
                new_name = f.replace(ending,r".pdf")
                new_file = os.path.abspath(path  + '\\' + new_name)
                deck.SaveAs(new_file, ppttoPDF) # formatType = 32 for ppt to pdf
                deck.Close()
                powerpoint.Quit()
                print('done')
                #os.remove(os.path.join(root,f))
                pass
            except:
                print('could not open')
                # os.remove(os.path.join(root,f))
        elif f.endswith(".ppt"):
            try:
                in_file=os.path.join(root,f)
                powerpoint = win32com.client.Dispatch("Powerpoint.Application")
                deck = powerpoint.Presentations.Open(in_file)
                in_file = os.path.abspath(path + '\\' + f)
                new_name = f.replace(ending,r".pdf")
                new_file = os.path.abspath(path  + '\\' + new_name)
                deck.SaveAs(new_file, ppttoPDF) # formatType = 32 for ppt to pdf
                deck.Close()
                powerpoint.Quit()
                print('done')
                #os.remove(os.path.join(root,f))
                pass
            except:
                print('could not open')
                # os.remove(os.path.join(root,f))
        else:
            pass

#%% Convert docx to txt
from docx import Document
import io
import shutil
import os

#Docx to Txt
def convertDocxToText(path):
    for d in os.listdir(path):
        fileExtension=d.split(".")[-1]
        if fileExtension =="docx":
            try:
                docxFilename = path + '/'+ d
                print(docxFilename)
                document = Document(docxFilename)
                textFilename = path + '/'+ d.split(".")[0] + ".txt"
                with io.open(textFilename,"w", encoding="utf-8") as textFile:
                    for para in document.paragraphs: 
                        textFile.write(str(para.text)) 
                pass
            except:
                print("could not open - ", docxFilename)